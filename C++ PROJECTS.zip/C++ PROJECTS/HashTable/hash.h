#include <iostream>
#include <string.h>
#include<bits/stdc++.h>
#include <cstdlib>
using namespace std;

struct item{
    string name;
    string regNo;
    string batchNo;

    item* next;
};

class hashtable{
    static const int total=15;
    item* HASHTABLE[total];

    public:

    hashtable();
    int hash(string);
    void Add(item);
    void Delete(item);
    void Search(string);
    void print();
    ~hashtable();
};


hashtable::hashtable(){
    for(int i=0; i<total; i++){
        HASHTABLE[i] = NULL;
    }
}
void toLower(string &key){
    transform(key.begin(), key.end(), key.begin(), ::tolower);
}
int hashtable::hash(string key){
    toLower(key);
    int index = 0;
    for(int i=0; i<key.length(); i++){
        index += (int)key[i];
    }

    index = index % total;
    return index;
}

void hashtable::Add(item newItem){
    int index = hash(newItem.name);
    toLower(newItem.name);
    if(HASHTABLE[index] == NULL){
        HASHTABLE[index] = new item;
        HASHTABLE[index]->name = newItem.name;
        HASHTABLE[index]->batchNo = newItem.batchNo;
        HASHTABLE[index]->next = NULL;
        HASHTABLE[index]->regNo = newItem.regNo;
        return;
    }

    item* ptr;
    ptr = HASHTABLE[index];

    item* node;
    node = new item;
    node->name = newItem.name;
    node->batchNo = newItem.batchNo;
    node->next = NULL;
    node->regNo = newItem.regNo;

    while(ptr->next != NULL){
        ptr = ptr->next;
    }

    ptr->next = node;
}


void hashtable::Delete(item ITEM){
    toLower(ITEM.name);
    bool found = false;
    int index = hash(ITEM.name);
    item* node1, *node2;
    node1 = HASHTABLE[index];
    node2 = HASHTABLE[index];

    while(node1 != NULL){
        if(node1->name == ITEM.name && node1->batchNo == ITEM.batchNo && node1->regNo == ITEM.regNo){
            found = true;
            break;
        }
        if(node1 != HASHTABLE[index]){
            node2 = node2->next;
        }
        node1 = node1->next;
    }

    if(found == false){
        cout<<"\nITEM NOT FOUND\n";
        return;
    }

    if(node1 == HASHTABLE[index] && node1->next == NULL){
        delete HASHTABLE[index];
        HASHTABLE[index] = NULL;
    }

    else if(node1 == HASHTABLE[index] && node1->next != NULL){
        node2 = node2->next;
        delete HASHTABLE[index];
        HASHTABLE[index] = node2;
    }

    else if(node1->next == NULL && node1 != HASHTABLE[index]){
        node2->next = NULL;
        delete node1;
    }

    else if(node1->next != NULL && node1 != HASHTABLE[index]){
        item* ptr;
        ptr = node1;

        node1 = node1->next;
        node2->next = node1;
        delete ptr;
    }

    else{
        cout<<"\nSOMETHING WENT WRONG\n";
    }
}

void hashtable::Search(string name){
    toLower(name);
    bool found = false;
    int index = hash(name);
    item* node;
    node = HASHTABLE[index];

    while(node != NULL){
        if(node->name == name){
            cout<<"\nNAME: "<<node->name
                <<"\nREG NUMBER: "<<node->regNo
                <<"\nBATCH NUMBER: "<<node->batchNo<<"\n\n";
            found = true;
        }
        node = node->next;
    }

    if(found == false){
        cout<<"\nITEM NOT FOUND\n";
    }
}

void hashtable::print(){
    item* ptr;
    for(int i=0; i<total; i++){
        if(HASHTABLE[i] == NULL)
            continue;
        cout<<"\n\n-----------------------------------------------------------\n";
        cout<<HASHTABLE[i]->name<<"\n"<<HASHTABLE[i]->regNo<<"\n"<<HASHTABLE[i]->batchNo<<"\n\n";
        ptr = HASHTABLE[i];
        while(ptr->next != NULL){
            ptr = ptr->next;
            cout<<ptr->name<<"\n"<<ptr->regNo<<"\n"<<ptr->batchNo<<"\n\n";;
        }
        cout<<"-----------------------------------------------------------\n\n";    
    }
}

hashtable::~hashtable(){
    item* ptr1, *ptr2;
    for(int i=0; i<total; i++){
        ptr1 = HASHTABLE[i];
        ptr2 = HASHTABLE[i];

        while(ptr1 != NULL){
            ptr1 = ptr1->next;
            delete ptr2;
        }
    }
}