#include <iostream>
#include <string>
#include "hash.h"
#include <windows.h>
using namespace std;

int main(){
    hashtable HASHY;
    item box;
    int choice = 1;
    while(choice != 0){
        cout<<"1. ADD\n"
            <<"2. PRINT\n"
            <<"3. DELETE\n"
            <<"4. SEARCH\n"
            <<"0. EXIT\n";

        cin>>choice;

        switch(choice){
            case 1:
                cout<<"NAME: ";
                cin>>box.name;
                cout<<"REG NUMBER: ";
                cin>>box.regNo;
                cout<<"BATCH: ";
                cin>>box.batchNo;
                HASHY.Add(box);
                break;
            case 2:
                HASHY.print();
                break;
            case 3:
                cout<<"NAME: ";
                cin>>box.name;
                cout<<"REG NUMBER: ";
                cin>>box.regNo;
                cout<<"BATCH: ";
                cin>>box.batchNo;
                HASHY.Delete(box);
                break;
            case 4:
                cout<<"NAME: ";
                cin>>box.name;
                HASHY.Search(box.name);
                break;
            default:
                cout<<"\nWRONG INPUT\n";
        }
        system("pause");
        system("cls");
    }

}