#include <iostream>
#include <iomanip>
using namespace std;

//This function will convert integers to Roman Numbers
string integerToRoman(int number) {

    string romanInString[] = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
    int romanValues[] = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
    string result = "";

    for (int i = 0; i < 13; ++i)
    {
        while(number - romanValues[i] >= 0)
        {
            result += romanInString[i];
            number -= romanValues[i];
        }
    }
    return result;
}


int main(){
    double num[3];
    double result=0;
    int intResult;
    string oper[3];
    oper[2] = " ";
    int i =0;

    cout<<"Input the formula: ";
    while(true){
        //if user enters only 2 numbers
        if(i==0)
            cin>>num[i]>>oper[i]>>num[i+1]>>oper[i+1];
        //else if the user enters 3 numbers
        else{
            cin>>num[i+1]>>oper[i+1];
            break;
        }
        i++;
        if(oper[i] == "="){
            break;
        }
    }

    //every possibility
    if(oper[2] == "="){
        if(oper[0] == "/"){
            if(oper[1] == "/"){
                result = num[0] / num[1] /num[2];
            }
            else if(oper[1] == "*"){
                result = num[0] / num[1] *num[2];

            }
            else if(oper[1] == "-"){
                result = num[0] / num[1] -num[2];

            }
            else if(oper[1] == "+"){
                result = num[0] / num[1] +num[2];

            }
        }
        else if(oper[0] == "*"){
            if(oper[1] == "/"){
                result = num[0] * num[1] /num[2];
            }
            else if(oper[1] == "*"){
                result = num[0] * num[1] *num[2];

            }
            else if(oper[1] == "-"){
                result = num[0] * num[1] -num[2];

            }
            else if(oper[1] == "+"){
                result = num[0] * num[1] +num[2];

            }
        }
        else if(oper[0] == "-"){
            if(oper[1] == "/"){
                result = num[0] - num[1] /num[2];
            }
            else if(oper[1] == "*"){
                result = num[0] - num[1] *num[2];

            }
            else if(oper[1] == "-"){
                result = num[0] - num[1] -num[2];

            }
            else if(oper[1] == "+"){
                result = num[0] - num[1] +num[2];

            }
        }
        else if(oper[0] == "+"){
            if(oper[1] == "/"){
                result = num[0] + num[1] /num[2];
            }
            else if(oper[1] == "*"){
                result = num[0] + num[1] *num[2];

            }
            else if(oper[1] == "-"){
                result = num[0] + num[1] -num[2];

            }
            else if(oper[1] == "+"){
                result = num[0] + num[1] +num[2];

            }
        }
    }

    else{
        if(oper[0] == "/"){
            result = num[0] / num[1];
        }
        else if(oper[0] == "*"){
            result = num[0] * num[1];

        }
        else if(oper[0] == "-"){
            result = num[0] - num[1];

        }
        else if(oper[0] == "+"){
            result = num[0] + num[1];
        }
    }


    //Now if the result is an interger than it will be converted in Roman number
    if(result == int(result)){
        intResult = (int)result;
        cout<<"The answer is: "<<intResult<<endl;
        cout<<"In Roman numerals, "<<intResult<<" is "<<integerToRoman(intResult);
    }

    //else the output will be displayed on the screen upto 4 decimal digits
    else{
        cout << fixed;
        cout << setprecision(4);
        cout<<"The answer is: "<<result;
    }

}
