#include <iostream>
using namespace std;
int main() {
   char s[20] = "18.2894 is a number";
   char *p;
   double result;
   result = strtod(s, &p);
   cout<<"The number after conversion of string : "<<result;
   return(0);
}