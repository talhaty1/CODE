#include <iostream>
using namespace std;

//This function will convert integers to Roman Numbers
string integerToRoman(int number) {

    string romanInString[] = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
    int romanValues[] = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
    string result = "";

    //nested loop to convert the integers to Roman numbers
    for (int i = 0; i < 13; ++i)
    {
        while(number - romanValues[i] >= 0)
        {   
            //Rules for conversion
            result += romanInString[i];
            number -= romanValues[i];
        }
    }
    return result;
}



int main(){
    int num;
    cout<<"Input the integer: ";
    cin>>num;
    cout<<"In Roman numerals, "<<num<<" is "<<integerToRoman(num);
}