#include <iostream>
#include <string>
#include <cstring>
using namespace std;

class STRING{
private:
    char *ARRAY;
    int SIZE;
public:
    STRING(const char *array);
    STRING(int size);
    STRING();
    ~STRING();
    int Size_string(const char *array);
    int Size_ARRAY();
    void set_ARRAY(const char *array);
    void set_newARRAY(const char *array);

    STRING operator+(STRING &string);
    void operator+=(STRING &string);
    void operator=(STRING string);  
    void print(){
        for(int i=0; i<SIZE; i++)
        {
            cout<<ARRAY[i];
        }
    }
};

int main(){
    STRING c;
    STRING a("abc");
    STRING b("123");
    c = a+b;
    a.print();
    b.print();
    c.print();
}


STRING::STRING(const char *array){
    SIZE = Size_string(array);
    ARRAY = new char[SIZE];
    strcpy(ARRAY, array);
}
STRING::STRING(int size){
    SIZE = size;
    ARRAY = new char[SIZE];
}
STRING::STRING(){
    SIZE = 50;
    ARRAY = new char[SIZE];
}
STRING::~STRING(){
    delete[] ARRAY;
}   
int STRING::Size_string(const char *array){
    return strlen(array);
}       
int STRING::Size_ARRAY(){
    return strlen(ARRAY);
}

void STRING::set_ARRAY(const char *array)
{
    // SIZE = strlen(array);
    // delete[] ARRAY;
    // ARRAY = new char[SIZE];
    for(int i = 0; i<SIZE; i++){
        ARRAY[i] = array[i];
    }
}

void STRING::set_newARRAY(const char *array)
{
    SIZE = strlen(array);
    delete[] ARRAY;
    ARRAY = new char[SIZE];
    for(int i = 0; i<SIZE; i++){
        ARRAY[i] = array[i];
    }
}

STRING STRING::operator+(STRING &string){
    int size1,size2,size;
    char *temp;
    size1 = this->Size_ARRAY();
    size2 = string.Size_ARRAY();
    size = size1 + size2;
    temp = new char[size];
    int j=0;
    for(int i=0; i < size1; i++)
    {
        temp[i] = this->ARRAY[i];
        j++;
    }
    for(int i=0; i < size2; i++)
    {
        temp[j] = string.ARRAY[i];
        j++;
    }
    // cout<<temp;
    STRING result(temp);
    return result;
}
void STRING::operator+=(STRING &string){
    // int size1,size2,size;
    // char *temp;
    // size1 = this->Size_ARRAY();
    // size2 = string.Size_ARRAY();
    // size = size1 + size2;
    // temp = new char[size];
    // int j=0;
    // for(int i=0; i < size1; i++)
    // {
    //     temp[i] = this->ARRAY[i];
    //     j++;
    // }
    // for(int i=0; i < size1; i++)
    // {
    //     temp[j] = this->ARRAY[i];
    //     j++;
    // }
    // this->set_ARRAY(temp, size);
}

void STRING::operator=(STRING string){
    this->set_newARRAY(string.ARRAY);
}