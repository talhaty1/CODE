//                                      2020497                  TALHA YUNUS
//                                      2020408                  RAJAB ALI

#include <iostream>
using namespace std;

class STRING{
private:
    char *ARRAY;
    int SIZE;
public:
    int stringLength(const char *array){
        int i=0;
        while(true){
            if(array[i] == '\0'){
                return i;
            }
            i++;
        }
    }
    void stringCopy(char *newArray, const char *oldArray){
        int i=0;
        while(oldArray[i] != '\0'){
            newArray[i] = oldArray[i];
            i++;
        }
    }
    STRING(const char *array){
        SIZE = stringLength(array);
        ARRAY = new char[SIZE];
        stringCopy(ARRAY, array);
    }
    STRING(int size){
        SIZE = size;
        ARRAY = new char[SIZE];
    }
    STRING(){
        SIZE = 50;
        ARRAY = new char[SIZE];
    }
    ~STRING(){
        delete[] ARRAY;
    }   
    int Size_string(const char *array){
        return stringLength(array);
    }       
    int Size_ARRAY(){
        return stringLength(ARRAY);
    }
    void set_ARRAY(const char *array){
        stringCopy(ARRAY, array);
    }
    void set_newARRAY(const char *array){
        SIZE = stringLength(array);
        delete[] ARRAY;
        ARRAY = new char[SIZE];
        stringCopy(ARRAY, array);
    }


    //OPEERATOR OVERLOADING

    void operator=(STRING a){
        this->set_newARRAY(a.ARRAY);
    }
    void operator=(const char* a){
        this->set_newARRAY(a);
    }
    STRING operator+(STRING &a){
        char* temp;
        STRING obj;
        int size = this->SIZE + a.SIZE;
        temp = new char[size+1];
        int j=0;
        for(int i=0; i<this->SIZE; i++, j++){
            temp[j] = this->ARRAY[i];
        }
        for(int i=0; i<a.SIZE; i++, j++){
            temp[j] = a.ARRAY[i];
            if(i==this->SIZE-1)
                temp[j+1] = '\0';
        }
        obj.set_newARRAY(temp);
        delete[] temp;
        return obj;
    }
    void operator+=(STRING &b){
        STRING obj, a;
        a.set_newARRAY(this->ARRAY);
        obj = a+b;
        cout<<obj<<endl;
        this->set_newARRAY(obj.ARRAY);
    }
    char& operator[](const int &i){
        if (i < SIZE && i>=0)
            return this->ARRAY[i];
        else
            cerr<<"\n\tACCESSING OUT OF BOUND CHARACTER\n";
    }
    bool operator==(const STRING &a){
        if(a.SIZE == this->SIZE){
            for(int i=0; i < this->SIZE; i++){
                if(a.ARRAY[i] != this->ARRAY[i])
                    return false;
            }
            return true;
        }
        else{
            return false;
        }
    }
    bool operator!=(const STRING &a){
        if(a.SIZE == this->SIZE){
            for(int i=0; i < this->SIZE; i++){
                if(a.ARRAY[i] != this->ARRAY[i])
                    return true;
            }
            return false;
        }
        else{
            return true;
        }
    }
    bool operator>(const STRING &a){
        if(a.SIZE >= this->SIZE){
            for(int i=0; i < this->SIZE; i++){
                if(a.ARRAY[i] > this->ARRAY[i])
                    return false;
                else if(a.ARRAY[i] < this->ARRAY[i])
                    return true;
            }
            return false;
        }
        else if(a.SIZE < this->SIZE){
            for(int i=0; i < a.SIZE; i++){
                if(a.ARRAY[i] > this->ARRAY[i])
                    return false;
                else if(a.ARRAY[i] < this->ARRAY[i])
                    return true;
            }
            return false;
        }
    }
    bool operator<(const STRING &a){
        STRING obj;
        obj.set_newARRAY(this->ARRAY);
        if(obj>a)
            return false;
        else 
            return true;
    }
    friend istream& operator>>(istream &input, STRING &a){
        char* temp;
        temp = new char[50];
        input>>temp;
        a.set_newARRAY(temp);
        delete[] temp;
        return input;
    } 
    friend ostream& operator<<(ostream &output, STRING &a){
        output<<a.ARRAY;
        return output;
    } 
    char* operator()(int a, int b){
        char *c;
        if(a<b){
            c = new char[b-a+3];
            for(int i=a, j=0; i<=b; i++, j++){
                c[j] = this->ARRAY[i];
                if(i==b)
                    c[j+1]='\0';
            }
            return c;
        }
    }
    char* operator<<(int i){
        char* array;
        if(i < this->SIZE){
            array = new char[i+1];
            // int k=0;
            for(int j=0; j<i; j++){
                array[j] = this->ARRAY[j] - i;
                if(j == i-1){
                    array[j+1] = '\0';
                    break;
                }
            }
        }
        else{
            array = new char[this->SIZE];
            array = this->ARRAY;
            for(int j=0; j<this->SIZE; j++){
                array[j] = this->ARRAY[j] - i;
            }
        }
        return array;
    }
    char* operator>>(int i){
        char* array;
        if(i < this->SIZE){
            array = new char[i+1];
            int k=0;
            for(int j=i-1; j<this->SIZE; j++){
                array[k] = this->ARRAY[j] + i;
                if(j == this->SIZE-1)
                    array[k+1] = '\0';
                k++;
            }
        }
        else{
            array = new char[this->SIZE];
            array = this->ARRAY;
            for(int j=0; j<this->SIZE; j++){
                array[j] = this->ARRAY[j] + i;
            }
        }
        return array;
    }
};


int main(){
    STRING a("TALHA"), b("YUNUS"),c;
    cout<<"\ta: "<<a<<"\tb: "<<b<<endl<<endl;

    //          +
    c = a+b;
    cout<<"c = a + b     \t----->>>\t   c:    "<<c<<endl;
    a="TALHA";b="YUNUS";

    //          +=
    a += b;
    cout<<"a += b        \t----->>>\t   a:    "<<a<<endl;
    a="TALHA";b="YUNUS";

    //          []
    cout<<"a[2]          \t----->>>\ta[2]:    "<<a[2]<<endl;
    char d=a[1];
    cout<<"d = a[1]      \t----->>>\t   d:    "<<d<<endl;
    a="TALHA";b="YUNUS";

    //          ==
    bool check=(a==b);
    cout<<"a == b        \t----->>>\t    :    "<<check<<endl;
    check=(a==a);
    cout<<"a == a        \t----->>>\t    :    "<<check<<endl;
    a="TALHA";b="YUNUS";

    //          !=
    check=(a!=b);
    cout<<"a != b        \t----->>>\t    :    "<<check<<endl;
    check=(a!=a);
    cout<<"a != a        \t----->>>\t    :    "<<check<<endl;
    a="TALHA";b="YUNUS";

    //          >
    check=(a>b);
    cout<<"a > b         \t----->>>\t    :    "<<check<<endl;
    a="TALHA";b="YUNUS";

    //          <
    check=(a<b);
    cout<<"a < b         \t----->>>\t    :    "<<check<<endl;
    a="TALHA";b="YUNUS";

    //          ()
    c = a(1,3);
    cout<<"c = a(1, 3)   \t----->>>\t   c:    "<<c<<endl;
    a="TALHA";b="YUNUS";
    
    //          =
    a="ALI";
    cout<<"a = \"ALI\"   \t----->>>\t   a:    "<<a<<endl;
    a="TALHA";b="YUNUS";

    //          <<
    char *i;
    i= new char[30];
    i=b<<1;
    cout<<"b << 1        \t----->>>\t    :    "<<i<<endl;
    i = b<<7;
    cout<<"b << 7        \t----->>>\t    :    "<<i<<endl;
    a="TALHA";b="YUNUS";
    delete[] i;

    //          >>
    i = a>>2;
    cout<<"a >> 2         \t----->>>\t    :    "<<i<<endl;
    i = a>>6;
    cout<<"a >> 6         \t----->>>\t    :    "<<i<<endl;
    a="TALHA";b="YUNUS";

    cin.get();
}
