#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <windows.h>
using namespace std;

void Login();
void Register();
bool checkRepeat(string);

int main(){
    int choice=0;

    while(choice != 3){
        cout<<"\n1.  LOGIN\n"
            <<"\n2.  REGISTER\n"
            <<"\n3. EXIT\n";
        cin>>choice;
        system("CLS");
        if(choice == 1){
            Login();
        }

        else if(choice == 2){
            Register();
        }

        else{
            cout<<"\nWRONG INPUT\n";
        }
    }
}


void Login(){
    bool check = false;
    ifstream readUser;
    readUser.open("usernames.dat");
    ifstream readPass;
    readPass.open("passwords.dat");
    string username, password;
    cin.ignore();
    cout<<"ENTER YOUR USERNAME: ";
    getline(cin, username);
    cout<<"ENTER YOU PASSWORD: ";
    getline(cin,password);

    string pass, user;
    while(!readUser.eof()){
        getline(readUser, user);
        getline(readPass, pass);
        if(user == username && pass == password){
            check = true;
            break;
        }
    }

    if(check == true){
        cout<<"\nLogin Successful\n";
    }
    else{
        cout<<"\nLogin Failed\nEither username or password is wrong\n";
    }

    readPass.close();
    readUser.close();
}

bool checkRepeat(string username){
    bool check = false;
    ifstream readUser;
    readUser.open("usernames.dat");

    string  user;
    while(!readUser.eof()){
        getline(readUser, user);
        if(user == username){
            check = true;
            break;
        }
    }

    readUser.close();
    return check;
}
void Register(){
    ofstream writeUser;
    ofstream writePass;
    writeUser.open("usernames.dat", ios::app);
    writePass.open("passwords.dat", ios::app);

    string username, password;
    bool check = false;
    cin.ignore();
    do{
        cout<<"\nENTER USERNAME: ";
        getline(cin, username);
        check = checkRepeat(username);
        if(check){
            cout<<"\nUSERNAME ALREADY USED\nENTER A DIFFERENT ONE\n";
        }
    }while(check);
    writeUser<<username<<'\n';
    cout<<"\nENTER PASSWORD: ";
    getline(cin, password);
    writePass<<password<<'\n';

    cout<<"\nSUCCESSFUL\nNOW YOU CAN LOGIN\n";

    writePass.close();
    writeUser.close();
}