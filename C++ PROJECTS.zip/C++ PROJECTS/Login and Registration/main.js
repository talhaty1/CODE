const fs = require('fs');

let a = fs.readFileSync('usernames.dat');

console.log(a.toString());

let b = fs.writeFile('abc.txt', 'HELLO WORLD', ()=>{console.log('written')});

fs.appendFile('abc.txt', '\nappended', ()=>{})
fs.mkdir('hello', ()=>{});

const express = require('express');

express.response()