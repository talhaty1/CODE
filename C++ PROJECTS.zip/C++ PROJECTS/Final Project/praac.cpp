#include <iostream>
using namespace std;

int main(){
    char* name = new char;
    cin>>name;
    // name = "abc";
    cout<<name;
}