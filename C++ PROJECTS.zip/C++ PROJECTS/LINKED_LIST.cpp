#include <iostream>
using namespace std;

class List{
    int num;
    List* previous;
    List* head;

    public:
    List(){head=NULL;}

    void insert(int _num){
        List* insert = new List;
        insert->num = _num;
        insert->previous = head;
        head = insert;
    }
    void display(){
        if(head==NULL){
            cout<<"empty List\n";
            return;
        }

        List* temp = head;

        while(temp!=NULL){
            cout<<temp->num<<" ";
            temp= temp->previous;
        }
    }
    void pop(){
        head=head->previous;
    }
};
